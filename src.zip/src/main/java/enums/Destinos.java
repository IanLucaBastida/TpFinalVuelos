package enums;

public enum Destinos {
    TOKYO,
    BUENOS_AIRES,
    PARIS,
    ROMA,

}
