package modelos;


import enums.EstadoReserva;
import enums.MetodoPago;
import interfaces.Identificable;

import java.time.LocalDateTime;

public class Reserva implements Identificable {

    private int id;
    private LocalDateTime fechaReserva;
    protected EstadoReserva estado;
    protected Asiento asiento;
    protected Cliente cliente;
    protected MetodoPago metodoPago;
    protected Vuelo vuelo;

    public Reserva(EstadoReserva estado, Asiento asiento, Cliente cliente, MetodoPago metodoPago, Vuelo vuelo) {
        this.fechaReserva = LocalDateTime.now();
        this.estado = estado;
        this.asiento = asiento;
        this.cliente = cliente;
        this.metodoPago = metodoPago;
        this.vuelo = vuelo;
    }

    public LocalDateTime getFechaReserva() {
        return fechaReserva;
    }

    public void setFechaReserva(LocalDateTime fechaReserva) {
        this.fechaReserva = fechaReserva;
    }

    public EstadoReserva getEstado() {
        return estado;
    }

    public void setEstado(EstadoReserva estado) {
        this.estado = estado;
    }

    public Asiento getAsiento() {
        return asiento;
    }

    public void setAsiento(Asiento asiento) {
        this.asiento = asiento;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public MetodoPago getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(MetodoPago metodoPago) {
        this.metodoPago = metodoPago;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    public double calcularTotal(){


        return
    }
    @Override
    public int getId() {
        return this.id;
    }


}
